export default () => {
    return (
        <div className="container">
            <div className="alert alert-danger" role="alert">
                Sorry but the Signature is invalid. Please try again.
            </div>
        </div>
    );
};
